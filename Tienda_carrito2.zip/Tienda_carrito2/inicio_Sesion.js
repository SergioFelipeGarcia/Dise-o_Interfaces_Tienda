function iniciarSesion() {
    // Obtiene los valores del formulario y los guarda en sus variables
    const email_user = document.getElementById("email_user").value;
    const password = document.getElementById("password").value;
    
    console.log(email_user);

    // Verificar si el usuario ya existe en el almacenamiento local
    const usuariosRegistrados = JSON.parse(localStorage.getItem("usuariosRegistrados")) || [];
    const usuarioExistente = usuariosRegistrados.find(usuario => usuario.email_user === email_user)
    console.log(usuariosRegistrados);

    if (usuarioExistente) {
        // comprobamos que la constraseña introducida es correcta.
        if (usuarioExistente.password === password) {
            alert("Inicio de sesión exitoso");
            // Guardar el email del usuario en sessionStorage
            sessionStorage.setItem("email_usuario", email_user);

            // Redirigir a otra página
            window.location.href = "index.html";
        } else {
            alert("Contraseña incorrecta");
        }
    } else {
        alert("Usuario no registrado, registrese para continuar");
    }
    
    return false;
}