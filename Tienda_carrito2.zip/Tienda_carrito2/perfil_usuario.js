document.addEventListener("DOMContentLoaded", function () {
    const emailUsuario = sessionStorage.getItem("email_usuario");

    if (emailUsuario) {
        // El usuario tiene una sesión activa
        // Puedes usar el emailUsuario para personalizar la página, cargar datos, etc.
        console.log("Sesión activa para: " + emailUsuario);
        const usuariosRegistrados = JSON.parse(localStorage.getItem("usuariosRegistrados")) || [];
        const verdatosUsuario = usuariosRegistrados.find(usuario => usuario.email_user === emailUsuario);

        if (verdatosUsuario) {
            // Si el usuario existe, muestra sus datos en la consola
            console.log("Datos del usuario:");
            console.log("Nombre: " + verdatosUsuario.nombre);
            console.log("Apellido: " + verdatosUsuario.apellido);
            console.log("Domicilio: " + verdatosUsuario.domicilio);
            console.log("Código Postal: " + verdatosUsuario.postal);
            // Crear elementos con los datos del formulario
            var item = $('#perfil-form');
            var nombre = $('<div class="col"><label for="nombre" class="form-label">Nombre:</label><input type="text" class="form-control" id="nombre" value="' + verdatosUsuario.nombre + '"></div>');
            var apellido = $('<div class="col"><label for="apellido" class="form-label">Apellido:</label><input type="text" class="form-control" id="apellido" value="' + verdatosUsuario.apellido + '"></div>');
            var domicilio = $('<div class="col"><label for="domicilio" class="form-label">Domicilio:</label><input type="text" class="form-control" id="domicilio" value="' + verdatosUsuario.domicilio + '"></div>');
            var postal = $('<div class="col"><label for="codpostal" class="form-label">Código Postal:</label><input type="number" class="form-control" id="codpostal" value="' + verdatosUsuario.postal + '"></div>');
            item.append(nombre);
            item.append(apellido);
            item.append(domicilio);
            item.append(postal);
            // Añadir el formulario al contenedor
            $('#perfil-form').append(item);
            // ahora los datos de la compra
            mostrarCompras();
        } else {
            console.log("Usuario no encontrado en el almacenamiento.");
        }
    } else {
        // No hay sesión activa, redirigir a la página de inicio de sesión o mostrar un mensaje de error.
        alert("Por favor, inicie sesión para poder ver su perfil.");
        window.location.href = "login.html"; // Redirige a la página de inicio de sesión
    }
    

    function mostrarCompras() {
        console.log("entro en la función mostrar compras")
        const emailUsuario = sessionStorage.getItem("email_usuario");
        const listadeRegistrados = JSON.parse(localStorage.getItem("usuariosRegistrados")) || [];
    
        const usuarioActual = listadeRegistrados.find(usuario => usuario.email_user === emailUsuario);
        console.log("muestro lo que tiene de compras" , usuarioActual.compras) // ok hasta aquí
        if (usuarioActual) {
            const comprasRealizadas = usuarioActual.compras || [];
    
            if (comprasRealizadas.length > 0) {
                // Crear y mostrar la tabla de compras
                const tablaCompras = $('#tabla-compras');
    
                comprasRealizadas.forEach((compra, index) => {
                    const fila = `<tr>
                                    <th scope="row">${index + 1}</th>
                                    <td>${compra.fecha}</td>
                                    <td>${compra.articulo}</td>
                                    <td>${compra.cantidad}</td>
                                    <td>${compra.precio}</td>
                                    <td><b>${compra.totalcompra}</b></td>
                                 </tr>`;
                    // Crear un elemento jQuery a partir del código HTML de la fila
                    const filaElemento = $(fila);
                    
                    // Añadir la fila al cuerpo de la tabla
                    $('#perfil-table tbody').append(filaElemento);
                });
    
                // Añadir la tabla al contenedor
                $('#perfil-table').append(tablaCompras);
            } else {
                console.log("El usuario no ha realizado compras.");
            }
        } else {
            console.log("Usuario no encontrado en el almacenamiento.");
        }
              
    }
 
    
    

    

});



function enviar() {
    alert("¡Enviado con éxito gracias por su opinion !");
}