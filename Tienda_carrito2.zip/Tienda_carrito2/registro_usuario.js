

function RegistrarUsuario() {
    // Obtiene los valores del formulario y los guarda en sus variables
    const email_user = document.getElementById("email_user").value;
    const password = document.getElementById("password").value;
    const nombre = document.getElementById("Nombre_user").value;
    const apellido = document.getElementById("apellido_user").value;
    const domicilio = document.getElementById("domicilio").value;
    const postal = document.getElementById("cod_postal").value;
    

    // Verificar si el usuario ya existe en el almacenamiento local
    const usuariosRegistrados = JSON.parse(localStorage.getItem("usuariosRegistrados")) || [];
    const usuarioExistente = usuariosRegistrados.find(usuario => usuario.email_user === email_user);
    if (usuarioExistente) {
        alert("Este usuario ya está registrado.");
        return;
    }
    // Agregar el nuevo usuario a la lista de usuarios registrados
    usuariosRegistrados.push({ email_user, password,nombre,apellido,domicilio,postal });
    localStorage.setItem("usuariosRegistrados", JSON.stringify(usuariosRegistrados));
    console.log(usuariosRegistrados)
    alert("Registro exitoso");
    // Redirigir a otra página
    window.location.href = "index.html";

    return false;
}

