var CAT_URL; 
// Tengo que definir CAT_URL fuera para poder utilizarla en las 2 fuctions

function CategoriaSeleccionada() {
  // Obtengo el valor seleccionado en el formulario
  var selectedCategory = document.getElementById("categorySelect").value;
  // compruebo el  dato obtenido por consola  
  console.log("Categoría seleccionada: " + selectedCategory);
  
  // la meto en una const la url base para construir la url final que depende de la categoria
  const API_URL = "https://fakestoreapi.com/products/category/";
  
  CAT_URL = (`${API_URL}${selectedCategory}`);
  // compruebo que esta correctamente compuesta la url
  console.log("URL: " + CAT_URL);
  
 // Ahora que tengo la url hago la solictud para los productos del API de esa categoria
  $.get(CAT_URL, function(data) {
    // Como la página tiene productos hay que Limpiar el contenedor de productos
    console.log('Limpiando el contenedor de productos...');
    $('#productos-container').empty();
    console.log('Quedo limpio o no...');

    data.forEach(function(product) {
      // Crear un elemento 'div' con la clase 'item'
      var item = $('<div class="item"></div>');

      // Crear elementos 'span' para el título, precio y una imagen
      var title = $('<span class="titulo-item">' + product.title + '</span>');
      var price = $('<span class="precio-item">$' + product.price + '</span>');
      var image = $('<img src="' + product.image + '" alt="" class="img-item">');

      // Crear un botón "Agregar al Carrito"
      var button = $('<button class="boton-item">Agregar al Carrito</button>');

      // Agregar los elementos creados al elemento 'div' con la clase 'item'
      item.append(title);
      item.append(image);
      item.append(price);
      item.append(button);

      // Agregar el elemento 'div' al documento HTML
      $('#productos-container').append(item);
      // Agregar console.log para ver las variables
      console.log('Título: ' + product.title);
      console.log('Precio: $' + product.price);
      console.log('Imagen URL: ' + product.image);

    }); // cierro el forEach

  }); // cierro la fuction data
  return false;
  // ponemos return false para evitar que la pagina se recargue
  // si se recarga volveria a ejecutarse todo lo anterior pero no quiero que se ejecutetodo.
}